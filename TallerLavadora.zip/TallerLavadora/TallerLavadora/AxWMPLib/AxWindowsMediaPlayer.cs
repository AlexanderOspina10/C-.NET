﻿namespace AxWMPLib
{
    internal class AxWindowsMediaPlayer
    {
        public string URL { get; internal set; }
        public object Ctlcontrols { get; internal set; }
    }
}